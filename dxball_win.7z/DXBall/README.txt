-----------------------------------------------------------------

 Classic Game packed by GamesNostalgia.com

 If you like what we do, support us on Patreon:
 
	https://www.patreon.com/gamesnostalgia
 
 or with a donation:

	http://gamesnostalgia.com/donate
 
-----------------------------------------------------------------

 PLEASE NOTE:
 
 This is an old Windows game, most probably developed for Windows95.
 
 If you have problems running it, try executing it in compatibility
 mode, setting Windows 95 or Windows XP mode.
 
 If there is a .REG file in the archive, double click on it
 before launching the game.

-----------------------------------------------------------------

 Please go to http://gamesnostalgia.com for more retrogames